
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_TOKENS 500
#define MAX_LENGTH 50

int isKeyword(char word[])
{
    char keywords[][20] = {
        "int", "float", "char", "return", "for"
    };

    int i;

    for (i = 0; i < 5; i++)
    {
        if (strcmp(word, keywords[i]) == 0)
            return 1;
    }

    return 0;
}

int isOperator(char token[])
{
    char operators[][10] = {
        "+", "-", "*", "/", "=",
        "<", ">", "<=", ">=",
        "==", "!=", "++", "--"
    };

    int i;

    for (i = 0; i < 13; i++)
    {
        if (strcmp(token, operators[i]) == 0)
            return 1;
    }

    return 0;
}

int isNumber(char token[])
{
    int i;
    int dot = 0;

    for (i = 0; token[i] != '\0'; i++)
    {
        if (token[i] == '.')
        {
            dot++;

            if (dot > 1)
                return 0;
        }
        else if (!isdigit(token[i]))
        {
            return 0;
        }
    }

    return 1;
}

int exists(char array[][MAX_LENGTH], int size, char word[])
{
    int i;

    for (i = 0; i < size; i++)
    {
        if (strcmp(array[i], word) == 0)
            return 1;
    }

    return 0;
}

void addUnique(char array[][MAX_LENGTH], int *size, char word[])
{
    if (!exists(array, *size, word))
    {
        strcpy(array[*size], word);
        (*size)++;
    }
}

int main()
{
    char source[] =
        "int func(int xyz) { "
        "xyz=xyz+1; "
        "return xyz; "
        "} "
        "int main() { "
        "int a, b=5; "
        "for(int i=0;i<=10;i++) { "
        "b=b+func(i); "
        "} "
        "return 0; "
        "}";

    char tokens[MAX_TOKENS][MAX_LENGTH];

    char keywords[MAX_TOKENS][MAX_LENGTH];
    char functions[MAX_TOKENS][MAX_LENGTH];
    char variables[MAX_TOKENS][MAX_LENGTH];
    char operators[MAX_TOKENS][MAX_LENGTH];
    char others[MAX_TOKENS][MAX_LENGTH];

    int tokenCount = 0;
    int keywordCount = 0;
    int functionCount = 0;
    int variableCount = 0;
    int operatorCount = 0;
    int otherCount = 0;

    int i = 0;
    int j;

     while (source[i] != '\0')
    {
        if (isspace(source[i]))
        {
            i++;
        }

        else if (isalpha(source[i]) || source[i] == '_')
        {
            j = 0;

            while (isalnum(source[i]) || source[i] == '_')
            {
                tokens[tokenCount][j++] = source[i++];
            }

            tokens[tokenCount][j] = '\0';
            tokenCount++;
        }

        else if (isdigit(source[i]))
        {
            j = 0;

            while (isdigit(source[i]) || source[i] == '.')
            {
                tokens[tokenCount][j++] = source[i++];
            }

            tokens[tokenCount][j] = '\0';
            tokenCount++;
        }

        else if (
            (source[i] == '+' && source[i + 1] == '+') ||
            (source[i] == '-' && source[i + 1] == '-') ||
            (source[i] == '<' && source[i + 1] == '=') ||
            (source[i] == '>' && source[i + 1] == '=') ||
            (source[i] == '=' && source[i + 1] == '=') ||
            (source[i] == '!' && source[i + 1] == '=')
        )
        {
            tokens[tokenCount][0] = source[i];
            tokens[tokenCount][1] = source[i + 1];
            tokens[tokenCount][2] = '\0';

            tokenCount++;
            i += 2;
        }

        else
        {
            tokens[tokenCount][0] = source[i];
            tokens[tokenCount][1] = '\0';

            tokenCount++;
            i++;
        }
    }


    for (i = 0; i < tokenCount; i++)
    {

        if (isKeyword(tokens[i]))
        {
            addUnique(keywords, &keywordCount, tokens[i]);
        }

        else if (
            i + 1 < tokenCount &&
            strcmp(tokens[i + 1], "(") == 0 &&
            !isKeyword(tokens[i])
        )
        {
            addUnique(functions, &functionCount, tokens[i]);
        }

        else if (isOperator(tokens[i]))
        {
            addUnique(operators, &operatorCount, tokens[i]);
        }

        else if (
            (isalpha(tokens[i][0]) || tokens[i][0] == '_') &&
            !isKeyword(tokens[i])
        )
        {
            addUnique(variables, &variableCount, tokens[i]);
        }

        else
        {
            addUnique(others, &otherCount, tokens[i]);
        }
    }


    printf("Functions: ");
    for (i = 0; i < functionCount; i++)
    {
        printf("%s", functions[i]);

        if (i < functionCount - 1)
            printf(", ");
    }

    printf("\nOperators: ");
    for (i = 0; i < operatorCount; i++)
    {
        printf("%s", operators[i]);

        if (i < operatorCount - 1)
            printf(", ");
    }

    printf("\nVariables: ");
    for (i = 0; i < variableCount; i++)
    {
        printf("%s", variables[i]);

        if (i < variableCount - 1)
            printf(", ");
    }

    printf("\nKeywords: ");
    for (i = 0; i < keywordCount; i++)
    {
        printf("%s", keywords[i]);

        if (i < keywordCount - 1)
            printf(", ");
    }

    printf("\nOthers: ");
    for (i = 0; i < otherCount; i++)
    {
        printf("%s", others[i]);

        if (i < otherCount - 1)
            printf(", ");
    }

    printf("\n");

    return 0;
}
