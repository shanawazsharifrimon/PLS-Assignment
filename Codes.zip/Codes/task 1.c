#include <stdio.h>
#include <ctype.h>

int main()
{
char source[] =
"int func(int xyz) { xyz=xyz+1; return xyz; } "
"int main() { int a, b=5; "
"for(int i=0;i<=10;i++) { b=b+func(i); } "
"return 0; }";

int i = 0;

while (source[i] != '\0')
{
    if (isspace(source[i]))
    {
        i++;
    }
    else if (isalpha(source[i]) || source[i] == '_')
    {
        while (isalnum(source[i]) || source[i] == '_')
        {
            printf("%c", source[i]);
            i++;
        }
        printf("\n");
    }
    else if (isdigit(source[i]))
    {
        while (isdigit(source[i]) || source[i] == '.')
        {
            printf("%c", source[i]);
            i++;
        }
        printf("\n");
    }
    else if ((source[i] == '+' && source[i + 1] == '+') ||
             (source[i] == '-' && source[i + 1] == '-') ||
             (source[i] == '<' && source[i + 1] == '=') ||
             (source[i] == '>' && source[i + 1] == '=') ||
             (source[i] == '=' && source[i + 1] == '=') ||
             (source[i] == '!' && source[i + 1] == '='))
    {
        printf("%c%c\n", source[i], source[i + 1]);
        i = i + 2;
    }
    else if (source[i] == '+' ||
             source[i] == '-' ||
             source[i] == '*' ||
             source[i] == '/' ||
             source[i] == '=' ||
             source[i] == '<' ||
             source[i] == '>')
    {
        printf("%c\n", source[i]);
        i++;
    }
    else if (source[i] == '(' ||
             source[i] == ')' ||
             source[i] == '{' ||
             source[i] == '}' ||
             source[i] == ';' ||
             source[i] == ',')
    {
        printf("%c\n", source[i]);
        i++;
    }
    else
    {
        i++;
    }
}

return 0;

}
