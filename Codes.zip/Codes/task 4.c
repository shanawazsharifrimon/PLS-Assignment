#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define MAX_TOKENS 500
#define MAX_LENGTH 50
#define MAX_VARIABLES 100
#define MAX_CHILDREN 10


typedef struct Node
{
char name[MAX_LENGTH];
struct Node *children[MAX_CHILDREN];
int childCount;
} Node;

char variables[MAX_VARIABLES][MAX_LENGTH];
char variableTypes[MAX_VARIABLES][MAX_LENGTH];

int variableCount = 0;
char tokens[MAX_TOKENS][MAX_LENGTH];

int tokenCount = 0;
int currentToken = 0;

int isKeyword(char word[])
{
char keywords[][20] =
{
"int",
"float",
"char",
"return",
"for"
};

int i;

for (i = 0; i < 5; i++)
{
    if (strcmp(word, keywords[i]) == 0)
    {
        return 1;
    }
}

return 0;


}

int isType(char word[])
{
if (strcmp(word, "int") == 0)
return 1;


if (strcmp(word, "float") == 0)
    return 1;

if (strcmp(word, "char") == 0)
    return 1;

return 0;

}
int isIdentifier(char word[])
{
if (!(isalpha(word[0]) || word[0] == '_'))
{
return 0;
}


if (isKeyword(word))
{
    return 0;
}

return 1;

}
int isNumber(char word[])
{
int i;
int dot = 0;


for (i = 0; word[i] != '\0'; i++)
{
    if (word[i] == '.')
    {
        dot++;

        if (dot > 1)
            return 0;
    }

    else if (!isdigit(word[i]))
    {
        return 0;
    }
}

return 1;


}
Node* createNode(char name[])
{
Node *node;


node = (Node*)malloc(sizeof(Node));

strcpy(node->name, name);

node->childCount = 0;

return node;


}

void addChild(Node *parent, Node *child)
{
parent->children[parent->childCount] = child;


parent->childCount++;


}

void printTree(Node *root, int level)
{
int i;


for (i = 0; i < level; i++)
{
    printf("  ");
}

printf("%s\n", root->name);


for (i = 0; i < root->childCount; i++)
{
    printTree(root->children[i], level + 1);
}


}

int findVariable(char name[])
{
int i;


for (i = 0; i < variableCount; i++)
{
    if (strcmp(variables[i], name) == 0)
    {
        return i;
    }
}

return -1;


}

void addVariable(char name[], char type[])
{
if (findVariable(name) == -1)
{
strcpy(variables[variableCount], name);


    strcpy(variableTypes[variableCount], type);

    variableCount++;
}


}
char* getVariableType(char name[])
{
int index;


index = findVariable(name);

if (index == -1)
{
    return "undefined";
}

return variableTypes[index];


}


void printSymbolTable()
{
int i;


printf("\n===== LOOKUP TABLE =====\n");

printf("ID\tVariable\tType\n");

for (i = 0; i < variableCount; i++)
{
    printf("%d\t%s\t\t%s\n",
           i + 1,
           variables[i],
           variableTypes[i]);
}


}

void tokenize(char source[])
{
int i = 0;
int j;


while (source[i] != '\0')
{

    /* Ignore space */

    if (isspace(source[i]))
    {
        i++;
    }


    /* Identifier or Keyword */

    else if (isalpha(source[i]) || source[i] == '_')
    {
        j = 0;

        while (isalnum(source[i]) || source[i] == '_')
        {
            tokens[tokenCount][j] = source[i];

            j++;

            i++;
        }

        tokens[tokenCount][j] = '\0';

        tokenCount++;
    }

    else if (isdigit(source[i]))
    {
        j = 0;

        while (isdigit(source[i]) || source[i] == '.')
        {
            tokens[tokenCount][j] = source[i];

            j++;

            i++;
        }

        tokens[tokenCount][j] = '\0';

        tokenCount++;
    }

    else if
    (
        (source[i] == '+' && source[i + 1] == '+') ||
        (source[i] == '-' && source[i + 1] == '-') ||
        (source[i] == '<' && source[i + 1] == '=') ||
        (source[i] == '>' && source[i + 1] == '=') ||
        (source[i] == '=' && source[i + 1] == '=') ||
        (source[i] == '!' && source[i + 1] == '=')
    )
    {
        tokens[tokenCount][0] = source[i];

        tokens[tokenCount][1] = source[i + 1];

        tokens[tokenCount][2] = '\0';

        tokenCount++;

        i = i + 2;
    }
    else
    {
        tokens[tokenCount][0] = source[i];

        tokens[tokenCount][1] = '\0';

        tokenCount++;

        i++;
    }
    }
}
char* getTokenType(char token[])
{
if (isNumber(token))
{
if (strchr(token, '.') != NULL)
{
return "float";
}


    return "int";
}


if (isIdentifier(token))
{
    return getVariableType(token);
}


return "unknown";


}


char* checkExpressionType(int start, int end)
{
int i;


char resultType[MAX_LENGTH];

strcpy(resultType, "unknown");


for (i = start; i < end; i++)
{
    if (isNumber(tokens[i]) ||
        isIdentifier(tokens[i]))
    {
        char *type;

        type = getTokenType(tokens[i]);


        if (strcmp(type, "undefined") == 0)
        {
            printf(
                "Semantic Error: Variable '%s' is not declared.\n",
                tokens[i]
            );

            return "error";
        }


        if (strcmp(resultType, "unknown") == 0)
        {
            strcpy(resultType, type);
        }


        else if
        (
            strcmp(resultType, "float") == 0 ||
            strcmp(type, "float") == 0
        )
        {
            strcpy(resultType, "float");
        }


        else
        {
            strcpy(resultType, "int");
        }
    }
}


if (strcmp(resultType, "unknown") == 0)
{
    return "unknown";
}


if (strcmp(resultType, "float") == 0)
{
    return "float";
}


return "int";


}

Node* parseExpression()
{
Node *expressionNode;


expressionNode = createNode("Expression");


while
(
    currentToken < tokenCount &&
    strcmp(tokens[currentToken], ";") != 0
)
{
    Node *child;

    child = createNode(tokens[currentToken]);

    addChild(expressionNode, child);

    currentToken++;
}


return expressionNode;


}
Node* parseDeclaration()
{
Node *declarationNode;


char type[MAX_LENGTH];

strcpy(type, tokens[currentToken]);


declarationNode = createNode("Declaration");



addChild(
    declarationNode,
    createNode(tokens[currentToken])
);

currentToken++;



if (isIdentifier(tokens[currentToken]))
{
    addVariable(
        tokens[currentToken],
        type
    );


    addChild(
        declarationNode,
        createNode(tokens[currentToken])
    );

    currentToken++;
}


if (strcmp(tokens[currentToken], "=") == 0)
{
    addChild(
        declarationNode,
        createNode("=")
    );

    currentToken++;


    int expressionStart;

    expressionStart = currentToken;


    Node *expression;

    expression = parseExpression();


    int expressionEnd;

    expressionEnd = currentToken;


    addChild(
        declarationNode,
        expression
    );


    char *rightType;

    rightType =
        checkExpressionType(
            expressionStart,
            expressionEnd
        );


    if
    (
        strcmp(type, rightType) != 0 &&
        strcmp(rightType, "error") != 0
    )
    {
        if
        (
            strcmp(type, "float") == 0 &&
            strcmp(rightType, "int") == 0
        )
        {
            /* Valid conversion */
        }

        else
        {
            printf(
                "Semantic Error: Cannot assign %s to %s variable.\n",
                rightType,
                type
            );
        }
    }
}


if (strcmp(tokens[currentToken], ";") == 0)
{
    addChild(
        declarationNode,
        createNode(";")
    );

    currentToken++;
}


return declarationNode;


}

Node* parseAssignment()
{
Node *assignmentNode;


char leftVariable[MAX_LENGTH];


assignmentNode = createNode("Assignment");


strcpy(
    leftVariable,
    tokens[currentToken]
);

addChild(
    assignmentNode,
    createNode(tokens[currentToken])
);

currentToken++;

if (strcmp(tokens[currentToken], "=") == 0)
{
    addChild(
        assignmentNode,
        createNode("=")
    );

    currentToken++;
}


int expressionStart;

expressionStart = currentToken;


Node *expression;

expression = parseExpression();


int expressionEnd;

expressionEnd = currentToken;


addChild(
    assignmentNode,
    expression
);

char *leftType;

char *rightType;


leftType =
    getVariableType(leftVariable);


rightType =
    checkExpressionType(
        expressionStart,
        expressionEnd
    );


if (strcmp(leftType, "undefined") == 0)
{
    printf(
        "Semantic Error: Variable '%s' is not declared.\n",
        leftVariable
    );
}


else if
(
    strcmp(leftType, rightType) != 0 &&
    strcmp(rightType, "error") != 0
)
{

    if
    (
        strcmp(leftType, "float") == 0 &&
        strcmp(rightType, "int") == 0
    )
    {

    }

    else
    {
        printf(
            "Semantic Error: Type mismatch. Cannot assign %s to %s variable '%s'.\n",
            rightType,
            leftType,
            leftVariable
        );
    }
}


if (strcmp(tokens[currentToken], ";") == 0)
{
    addChild(
        assignmentNode,
        createNode(";")
    );

    currentToken++;
}


return assignmentNode;


}


Node* parseProgram()
{
Node *programNode;


programNode = createNode("Program");


while (currentToken < tokenCount)
{


    if (isType(tokens[currentToken]))
    {
        Node *declaration;

        declaration =
            parseDeclaration();


        addChild(
            programNode,
            declaration
        );
    }


    else if
    (
        isIdentifier(tokens[currentToken]) &&
        strcmp(tokens[currentToken + 1], "=") == 0
    )
    {
        Node *assignment;

        assignment =
            parseAssignment();


        addChild(
            programNode,
            assignment
        );
    }


    else
    {
        currentToken++;
    }
}


return programNode;


}

int main()
{


char source[] =

    "int x; "

    "float y; "

    "int a = 5; "

    "x = 5 + 3; "

    "y = x + 2.6; "

    "x = y + 1;";


printf("====================================\n");

printf(" TASK 4: PARSER + PARSE TREE + SEMANTIC ANALYSIS\n");

printf("====================================\n");

tokenize(source);
 currentToken = 0;
Node *root;

root = parseProgram();


printf("\n===== PARSE TREE =====\n\n");

printTree(root, 0);


printSymbolTable();


printf("\n===== PROGRAM FINISHED =====\n");


return 0;

}
