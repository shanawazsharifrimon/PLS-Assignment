#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_TOKENS 500
#define MAX_LENGTH 50

int isKeyword(char word[])
{
    char keywords[][20] = {
        "int", "float", "char", "return", "for"
    };

    int i;

    for (i = 0; i < 5; i++)
    {
        if (strcmp(word, keywords[i]) == 0)
            return 1;
    }

    return 0;
}

int isOperator(char token[])
{
    char operators[][10] = {
        "+", "-", "*", "/", "=",
        "<", ">", "<=", ">=",
        "==", "!=", "++", "--"
    };

    int i;

    for (i = 0; i < 13; i++)
    {
        if (strcmp(token, operators[i]) == 0)
            return 1;
    }

    return 0;
}

int isIdentifier(char token[])
{
    if (!(isalpha(token[0]) || token[0] == '_'))
        return 0;

    return !isKeyword(token);
}

int exists(char array[][MAX_LENGTH], int size, char word[])
{
    int i;

    for (i = 0; i < size; i++)
    {
        if (strcmp(array[i], word) == 0)
            return 1;
    }

    return 0;
}

void addUnique(char array[][MAX_LENGTH], int *size, char word[])
{
    if (!exists(array, *size, word))
    {
        strcpy(array[*size], word);
        (*size)++;
    }
}

int main()
{
    char source[] =
        "int func(int xyz) { "
        "xyz=xyz+1; "
        "return xyz; "
        "} "
        "int main() { "
        "int a, b=5; "
        "for(int i=0;i<=10;i++) { "
        "b=b+func(i); "
        "} "
        "return 0; "
        "}";

    char tokens[MAX_TOKENS][MAX_LENGTH];

    char functions[MAX_TOKENS][MAX_LENGTH];
    char variables[MAX_TOKENS][MAX_LENGTH];
    char variableTypes[MAX_TOKENS][MAX_LENGTH];

    int tokenCount = 0;
    int functionCount = 0;
    int variableCount = 0;

    int i = 0;
    int j;

    while (source[i] != '\0')
    {
        if (isspace(source[i]))
        {
            i++;
        }

        else if (isalpha(source[i]) || source[i] == '_')
        {
            j = 0;

            while (isalnum(source[i]) || source[i] == '_')
            {
                tokens[tokenCount][j++] = source[i++];
            }

            tokens[tokenCount][j] = '\0';
            tokenCount++;
        }

        else if (isdigit(source[i]))
        {
            j = 0;

            while (isdigit(source[i]) || source[i] == '.')
            {
                tokens[tokenCount][j++] = source[i++];
            }

            tokens[tokenCount][j] = '\0';
            tokenCount++;
        }

        else if (
            (source[i] == '+' && source[i + 1] == '+') ||
            (source[i] == '-' && source[i + 1] == '-') ||
            (source[i] == '<' && source[i + 1] == '=') ||
            (source[i] == '>' && source[i + 1] == '=') ||
            (source[i] == '=' && source[i + 1] == '=') ||
            (source[i] == '!' && source[i + 1] == '=')
        )
        {
            tokens[tokenCount][0] = source[i];
            tokens[tokenCount][1] = source[i + 1];
            tokens[tokenCount][2] = '\0';

            tokenCount++;
            i += 2;
        }

        else
        {
            tokens[tokenCount][0] = source[i];
            tokens[tokenCount][1] = '\0';

            tokenCount++;
            i++;
        }
    }

    for (i = 0; i < tokenCount - 1; i++)
    {
        if (isIdentifier(tokens[i]) &&
            strcmp(tokens[i + 1], "(") == 0)
        {
            addUnique(functions, &functionCount, tokens[i]);
        }
    }


    for (i = 0; i < tokenCount; i++)
    {

        if (strcmp(tokens[i], "int") == 0 ||
            strcmp(tokens[i], "float") == 0 ||
            strcmp(tokens[i], "char") == 0)
        {
            char currentType[MAX_LENGTH];

            strcpy(currentType, tokens[i]);

            i++;

            while (i < tokenCount)
            {
                if (isIdentifier(tokens[i]) &&
                    !exists(functions, functionCount, tokens[i]))
                {
                    if (!exists(variables, variableCount, tokens[i]))
                    {
                        strcpy(variables[variableCount], tokens[i]);
                        strcpy(variableTypes[variableCount], currentType);
                        variableCount++;
                    }
                }

                if (strcmp(tokens[i], ";") == 0 ||
                    strcmp(tokens[i], ")") == 0)
                {
                    break;
                }

                i++;
            }
        }
    }

    printf("Functions: ");

    for (i = 0; i < functionCount; i++)
    {
        printf("%s", functions[i]);

        if (i < functionCount - 1)
            printf(", ");
    }

    printf("\n\nVariables:\n");

    for (i = 0; i < variableCount; i++)
    {
        printf("<%d id>\n", i + 1);
    }

    printf("\nLookup Table:\n");

    printf("ID\tVariable\tType\n");

    for (i = 0; i < variableCount; i++)
    {
        printf("%d\t%s\t\t%s\n",
               i + 1,
               variables[i],
               variableTypes[i]);
    }

    return 0;
}
